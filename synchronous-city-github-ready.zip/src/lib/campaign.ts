export const asset = (path: string) => `${import.meta.env.BASE_URL}${path}`;

const art = {
  city: asset("campaign/city-dome.png"),
  officerHero: asset("campaign/officer-hero.png"),
  officerPortrait: asset("campaign/officer-portrait.png"),
  officerPlate: asset("campaign/officer-plate.png"),
  wardenHero: asset("campaign/warden-hero.png"),
  wardenHarmony: asset("campaign/warden-harmony.png"),
  wardenPlate: asset("campaign/warden-cycle-plate.png"),
  runnerPlate: asset("campaign/runner-plate.png"),
  runnerSide: asset("campaign/runner-side.png"),
  runnerMotion: asset("campaign/runner-motion.png"),
  ascentBase: asset("campaign/ascent-base.png"),
  ascentMid: asset("campaign/ascent-mid.png"),
  bloodgrass: asset("campaign/bloodgrass.jpg"),
  ring: asset("campaign/bishops-ring.jpg"),
  bunny: asset("campaign/red-bunny.jpg"),
} as const;

export type ShiftId = "dawn" | "sol" | "noct";

export const shifts: Record<
  ShiftId,
  {
    id: ShiftId;
    name: string;
    hours: string;
    window: string;
    focus: string;
    notes: string[];
    motto: string;
  }
> = {
  dawn: {
    id: "dawn",
    name: "Dawnshift",
    hours: "Morning — Noon",
    window: "05:00 – 12:00",
    focus: "Growth, awakening, and the resetting of daily commerce.",
    notes: ["Gentle Awakening", "Hope", "Organic Unfolding"],
    motto: "The city inhales.",
  },
  sol: {
    id: "sol",
    name: "Solshift",
    hours: "Noon — Evening",
    window: "12:00 – 18:00",
    focus: "Peak power, heavy industry, and high-intensity urban operations.",
    notes: ["Radiant Energy", "Power · Industry", "Divine Presence"],
    motto: "The city works.",
  },
  noct: {
    id: "noct",
    name: "Noctshift",
    hours: "Evening — Night",
    window: "18:00 – 05:00",
    focus: "Reflection, dreams, nocturnal venues, and underground culture.",
    notes: ["Reflection", "Rest · Dreams", "Mystery"],
    motto: "The city remembers.",
  },
};

export const shiftOrder: ShiftId[] = ["dawn", "sol", "noct"];

export function shiftFromHour(hour: number): ShiftId {
  if (hour >= 5 && hour < 12) return "dawn";
  if (hour >= 12 && hour < 18) return "sol";
  return "noct";
}

export const city = {
  name: "Synchronous City",
  kicker: "Campaign Codex",
  slogan: "One people · One cycle · One tomorrow",
  motto: "Faster / Higher / Together",
  ascentMotto: "The higher we rise the closer we are together.",
  wardenCreed: ["Protect", "Guide", "Preserve", "Synchronize"],
  revision: "01",
  stats: [
    { label: "Shape", value: "Nonagon", detail: "Nine sides — three shifts, three times." },
    { label: "Population", value: "20–30M", detail: "Inhabitants inside the dome." },
    { label: "Diameter", value: "50–80 km", detail: "Wall to wall, measured at the ring." },
    { label: "Elevation", value: "~2,000 m", detail: "Center height of the plateau." },
  ],
};

export const people = [
  {
    id: "seraphrunner",
    role: "Seraphrunner Officer",
    division: "Security Division",
    creed: "Protecting the Cycle",
    summary:
      "Street-level keepers of the Cycle. A long ceremonial coat conceals lightweight composite armor until the city asks more of them.",
    portrait: art.officerPortrait,
    hero: art.officerHero,
    plate: art.officerPlate,
    quote: "The coat conceals the armor, until it is needed.",
    details: [
      {
        title: "Coat",
        body: "High collar, bloodsteel piping, and the city insignia at the shoulder. White over black — ceremony over force, until the reverse is required.",
      },
      {
        title: "Flex Armor",
        body: "A red hexagonal composite worn as a second skin. Flexible, durable, lightweight. Marked POLICE across the chest when the coat is open.",
      },
      {
        title: "Utility",
        body: "Belt and thigh straps for gear, communications, and supplies. Aegis-pattern boots for wet plazas and long watches.",
      },
    ],
  },
  {
    id: "warden",
    role: "Seraph Warden",
    division: "Cycle Guardians",
    creed: "A bridge between heaven and the cycle",
    summary:
      "Not merely a guardian. Wardens keep the city's covenant with the sky — flight, ceremony, and the quiet work of holding the Cycle in place.",
    portrait: art.wardenHarmony,
    hero: art.wardenHero,
    plate: art.wardenPlate,
    quote: "Not just a guardian, but a bridge between heaven and the cycle.",
    vestments: [
      {
        name: "Cycle Vestment",
        image: art.wardenHero,
        note: "White, ink, and bloodsteel. Worn for Sky Patrol and civic rite.",
      },
      {
        name: "Harmony Vestment",
        image: art.wardenHarmony,
        note: "Lavender aether and pale steel. Worn when the city must be seen as beautiful, not only kept.",
      },
    ],
    details: [
      {
        title: "Seraph Crown",
        body: "Headpiece modified for Sync City. Twin crescents, hanging seals, and a black moon — the night the Cycle never fully surrenders.",
      },
      {
        title: "Aether Wings",
        body: "Synchronized flight, stability, and combat assist. White blades with bloodsteel joints; idle they rest like a cathedral roof.",
      },
      {
        title: "Ceremonial Battle Suit",
        body: "Lightweight composite with a flex structure. Beauty is not the opposite of armor here — it is the point of it.",
      },
      {
        title: "Aegis Boots",
        body: "Terrain adaptation and silent step, for plazas that remember every footfall.",
      },
    ],
  },
] as const;

export const runner = {
  name: "Seraph Runner",
  kicker: "A motorcycle born from the light",
  lede: "Precision engineering with the grace of the Seraph. Not just a machine — a symbol of freedom, protection, and purpose.",
  motto: "Built for a brighter tomorrow",
  image: art.runnerSide,
  plate: art.runnerPlate,
  motion: art.runnerMotion,
  features: [
    {
      title: "Magnetic Levitation Wheels",
      body: "Frictionless. Silent. Precise. The rims carry a living red circuit that wakes when the machine is asked to run.",
    },
    {
      title: "Seraph Headlight",
      body: "An LED halo for status and mode, with an adaptive, focused beam. Angelic silhouette. Aerodynamic shield.",
    },
    {
      title: "AI Assisted Ride",
      body: "Learns. Adapts. Protects. The machine keeps the rider inside the Cycle even when the street does not.",
    },
    {
      title: "Ultra-Light Frame",
      body: "Carbon fiber married to Bloodsteel. The red is not paint — it is the city's metal, grown and forged.",
    },
  ],
};

export const infrastructure = [
  {
    id: "bloodsteel",
    title: "Bloodsteel",
    body: "The core red metal of the city. It is used in buildings, vehicles, weapons, clothing, spacecraft, the Seraphis Ascent, and the Seraphim's Wings. Red here is not decoration. It is continuity made solid.",
  },
  {
    id: "ascent",
    title: "Seraphis Ascent",
    body: "The elevator that binds Synchronous City to the orbital Seraphim's Wings. Bloodsteel engineering at civic scale. The climb is a pilgrimage as much as a transit.",
  },
  {
    id: "ring",
    title: "Seraphim's Wings",
    body: "A massive orbital ring, anchored in space and connected directly to the surface. The bridge between worlds. The future is not far.",
  },
];

export const biome = {
  lede: "A crimson ecosystem that serves as the energetic and physical lifeblood of the metropolis.",
  points: [
    {
      title: "Crimson Environment",
      body: "Vast Bloodgrass Fields, vibrant red flora and fauna, and glowing mineral conduits. The world outside the dome is not wasteland — it is a battery.",
    },
    {
      title: "Energy Ecosystem",
      body: "Plants, soil, and specialized wildlife generate and store ambient power. Nothing in the biome is merely ornamental.",
    },
    {
      title: "Underground Regulation",
      body: "A network of buried energy nodes regulates flow and distribution across the fields, then funnels harvest into the city through deep conduits.",
    },
  ],
  grass: [
    "The vital bridge connecting the sprawling city to the outer biome.",
    "Specialized in collecting solar and kinetic energy from environmental movement.",
    "Self-healing glowing conduits deliver power safely to transit arteries.",
  ],
  red: {
    symbolism: "Life, continuity, and deep symbiotic connection.",
    aesthetics:
      "Public rituals, high-end fashion, and brutalist architecture all keep the crimson. To wear red in Sync City is to admit you belong to the Cycle.",
  },
  bunnies: {
    title: "Red Bunnies",
    body: "Bioengineered fauna capable of storing and releasing bursts of energy. They keep localized ecosystem balance and energy stability — small, bright, and absolutely not pets, however much they look it.",
  },
};

export type ArchiveCategory =
  | "City"
  | "Cycle"
  | "Biome"
  | "Players"
  | "Fleet"
  | "Infrastructure";

export type CodexPath = "/city" | "/biome" | "/people" | "/fleet" | "/ascent";

export type ArchiveEntry = {
  id: string;
  category: ArchiveCategory;
  title: string;
  summary: string;
  body: string;
  href?: CodexPath;
  keys?: string[];
};

export const archive: ArchiveEntry[] = [
  {
    id: "sync-city",
    category: "City",
    title: "Synchronous City",
    summary: "A nonagonal city-state under glass, 20–30 million strong.",
    body: "Diameter 50–80 km, center elevation about 2,000 meters. The dome is not a prison — it is a metronome. Shops, vendors, and venues shift with the hours. The civic religion and the municipal timetable are the same document.",
    href: "/city",
  },
  {
    id: "nonagon",
    category: "City",
    title: "The Nine-Sided Plan",
    summary: "The city is a nonagon — three shifts, written in stone.",
    body: "Nine walls, nine long views toward the Seraphis Ascent. Three threes: Dawn, Sol, Noct. The geometry is a promise that the day will keep turning even if the people forget to.",
    href: "/city",
  },
  {
    id: "dawnshift",
    category: "Cycle",
    title: "Dawnshift",
    summary: "Morning to noon. The city inhales.",
    body: "Growth, awakening, and the resetting of daily commerce and municipal functions. Gentle awakening. Hope. Organic unfolding.",
    href: "/city",
  },
  {
    id: "solshift",
    category: "Cycle",
    title: "Solshift",
    summary: "Noon to evening. The city works.",
    body: "Peak power generation, heavy industry, and high-intensity urban operations. Radiant energy. Power, industry, divine presence.",
    href: "/city",
  },
  {
    id: "noctshift",
    category: "Cycle",
    title: "Noctshift",
    summary: "Evening to night. The city remembers.",
    body: "Reflection, dreams, nocturnal venues, and specialized underground culture. Mystery is scheduled, which does not make it less true.",
    href: "/city",
  },
  {
    id: "blood-biome",
    category: "Biome",
    title: "The Blood Biome",
    summary: "Crimson fields that feed the dome.",
    body: "Plants, soil, and wildlife generate and store ambient power. Buried nodes regulate the flow. Harvest moves into the city through deep conduits. The biome is the reason the lights stay on.",
    href: "/biome",
  },
  {
    id: "bloodgrass",
    category: "Biome",
    title: "Bloodgrass Fields",
    summary: "Solar and kinetic harvest at civic scale.",
    body: "The vital bridge between city and outer biome. Self-healing glowing conduits carry power to transit arteries. Wind over red grass is a kind of prayer, and also a kilowatt-hour.",
    href: "/biome",
  },
  {
    id: "red-meaning",
    category: "Biome",
    title: "The Cultural Role of Red",
    summary: "Life, continuity, symbiotic connection.",
    body: "Public ritual, high fashion, and brutalist architecture all keep the crimson. Bloodsteel is the same idea, made holdable.",
    href: "/biome",
  },
  {
    id: "red-bunnies",
    category: "Biome",
    title: "Red Bunnies",
    summary: "Engineered fauna that store and release energy.",
    body: "They maintain localized ecosystem balance and energy stability. Treat them as infrastructure that happens to have ears.",
    href: "/biome",
    keys: ["bunny", "rabbit", "fauna"],
  },
  {
    id: "seraphrunner",
    category: "Players",
    title: "Seraphrunner Officer",
    summary: "Security Division. The coat conceals the armor.",
    body: "White ceremonial coat, black lining, red flex-armor underneath. Faster, higher, together — and still on time for the next shift change.",
    href: "/people",
  },
  {
    id: "warden",
    category: "Players",
    title: "Seraph Warden",
    summary: "Bridge between heaven and the Cycle.",
    body: "Seraph Crown, Aether Wings, ceremonial battle suit. Protect, guide, preserve, synchronize. Sky Patrol is both a duty roster and a liturgy.",
    href: "/people",
  },
  {
    id: "runner",
    category: "Fleet",
    title: "Seraph Runner",
    summary: "A motorcycle born from the light.",
    body: "Magnetic levitation wheels, seraph-halo headlight, AI-assisted ride, carbon fiber and Bloodsteel frame. Silent until it is not.",
    href: "/fleet",
  },
  {
    id: "bloodsteel",
    category: "Infrastructure",
    title: "Bloodsteel",
    summary: "The city's red metal.",
    body: "Used in buildings, vehicles, weapons, clothing, spacecraft, the Ascent, and the Ring. If it matters, it has red in it.",
    href: "/ascent",
  },
  {
    id: "ascent",
    category: "Infrastructure",
    title: "Seraphis Ascent",
    summary: "The elevator between the city and the sky.",
    body: "Bloodsteel engineering linking the surface to the Seraphim's Wings. The higher we rise, the closer we are together.",
    href: "/ascent",
  },
  {
    id: "ring",
    category: "Infrastructure",
    title: "Seraphim's Wings",
    summary: "Orbital ring. The bridge between worlds.",
    body: "Anchored in space, connected directly to the surface. From the Ring, the dome looks like a held breath.",
    href: "/ascent",
  },
];

export const nav = [
  { to: "/", label: "Codex", exact: true },
  { to: "/city", label: "City" },
  { to: "/biome", label: "Biome" },
  { to: "/people", label: "Players" },
  { to: "/fleet", label: "Fleet" },
  { to: "/ascent", label: "Ascent" },
  { to: "/archive", label: "Archive" },
] as const;
