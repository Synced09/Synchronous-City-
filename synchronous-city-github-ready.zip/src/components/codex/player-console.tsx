import { BookOpen, Clock3, Map, RotateCcw, Save } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Band } from "@/components/codex/reveal";
import { useShift } from "@/components/providers";
import { shiftOrder, shifts, type ShiftId } from "@/lib/campaign";
import { cn } from "@/lib/utils";

const NOTES_KEY = "sync-city-player-notes";

function formatClock(date: Date) {
  return new Intl.DateTimeFormat(undefined, {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).format(date);
}

function nextShiftId(current: ShiftId) {
  const index = shiftOrder.indexOf(current);
  return shiftOrder[(index + 1) % shiftOrder.length]!;
}

function minutesUntilNextShift(now: Date, current: ShiftId) {
  const next = nextShiftId(current);
  const nextHour = next === "dawn" ? 5 : next === "sol" ? 12 : 18;
  const target = new Date(now);
  target.setHours(nextHour, 0, 0, 0);
  if (target <= now) target.setDate(target.getDate() + 1);
  return Math.max(0, Math.ceil((target.getTime() - now.getTime()) / 60000));
}

export function PlayerConsole() {
  const { shift, mode, setShift, followLive } = useShift();
  const [now, setNow] = useState(() => new Date());
  const [notes, setNotes] = useState("");
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 1000);
    try {
      setNotes(localStorage.getItem(NOTES_KEY) ?? "");
    } catch {
      // Storage can be unavailable in private browsing or embedded previews.
    }
    return () => window.clearInterval(id);
  }, []);

  const current = shifts[shift];
  const next = shifts[nextShiftId(shift)];
  const remaining = useMemo(() => minutesUntilNextShift(now, shift), [now, shift]);

  const saveNotes = () => {
    try {
      localStorage.setItem(NOTES_KEY, notes);
      setSaved(true);
      window.setTimeout(() => setSaved(false), 1400);
    } catch {
      setSaved(false);
    }
  };

  const clearNotes = () => {
    setNotes("");
    try {
      localStorage.removeItem(NOTES_KEY);
    } catch {
      // Ignore unavailable storage.
    }
  };

  return (
    <Band className="bg-ink text-paper">
      <div className="grid gap-10 lg:grid-cols-[1.1fr_0.9fr]">
        <div>
          <p className="kicker text-blood">Player terminal</p>
          <h2 className="display mt-4 text-4xl md:text-5xl">Keep your own record of the Cycle.</h2>
          <p className="mt-5 max-w-2xl text-paper/65">
            This is the player-facing layer of the Codex. Lock the city to a shift while
            investigating, return to Live when you want the world clock to drive the site,
            and keep private field notes in this browser.
          </p>

          <div className="mt-8 grid gap-3 sm:grid-cols-3">
            {shiftOrder.map((id) => (
              <button
                key={id}
                type="button"
                onClick={() => setShift(id)}
                className={cn(
                  "rounded-[var(--radius-md)] border px-4 py-4 text-left transition",
                  shift === id
                    ? "border-blood bg-blood/15"
                    : "border-paper/15 bg-paper/5 hover:border-paper/30",
                )}
              >
                <span className="kicker text-paper/50">{shifts[id].window}</span>
                <span className="display mt-2 block text-2xl">{shifts[id].name}</span>
              </button>
            ))}
          </div>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={followLive}
              className={cn(
                "kicker inline-flex h-10 items-center gap-2 rounded-full px-4",
                mode === "live" ? "bg-paper text-ink" : "border border-paper/20 text-paper/70",
              )}
            >
              <Clock3 className="size-4" />
              {mode === "live" ? "Following live" : "Return to Live"}
            </button>
            <span className="kicker text-paper/45">Local time · {formatClock(now)}</span>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-1">
          <div className="rounded-[var(--radius-lg)] border border-paper/10 bg-paper/[0.04] p-6">
            <p className="kicker text-blood">Observed cycle</p>
            <div className="mt-3 flex items-end justify-between gap-4">
              <span className="display text-4xl">{current.name}</span>
              <span className="kicker text-paper/50">{current.window}</span>
            </div>
            <p className="mt-4 text-sm text-paper/60">{current.motto} Next: {next.name} in roughly {remaining} min.</p>
          </div>
          <div className="rounded-[var(--radius-lg)] border border-paper/10 bg-paper/[0.04] p-6">
            <p className="kicker text-blood">Field notes</p>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Names, clues, places, suspicious details…"
              className="mt-3 min-h-28 w-full resize-y rounded-[var(--radius-md)] border border-paper/10 bg-ink/60 p-3 text-sm text-paper outline-none placeholder:text-paper/30 focus:border-blood/60"
              aria-label="Private player field notes"
            />
            <div className="mt-3 flex items-center justify-between gap-3">
              <button type="button" onClick={clearNotes} className="kicker inline-flex items-center gap-2 text-paper/45 hover:text-paper">
                <RotateCcw className="size-3.5" /> Clear
              </button>
              <button type="button" onClick={saveNotes} className="kicker inline-flex items-center gap-2 rounded-full bg-blood px-4 py-2 text-paper">
                <Save className="size-3.5" /> {saved ? "Saved" : "Save notes"}
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-10 grid gap-3 sm:grid-cols-3">
        <Link to="/city" className="group rounded-[var(--radius-md)] border border-paper/10 bg-paper/[0.03] p-5 hover:border-blood/50">
          <Map className="size-5 text-blood" />
          <span className="display mt-4 block text-2xl">City schematic</span>
          <span className="mt-2 block text-sm text-paper/50">Inspect the nonagon and its clickable layers.</span>
        </Link>
        <Link to="/archive" className="group rounded-[var(--radius-md)] border border-paper/10 bg-paper/[0.03] p-5 hover:border-blood/50">
          <BookOpen className="size-5 text-blood" />
          <span className="display mt-4 block text-2xl">Field archive</span>
          <span className="mt-2 block text-sm text-paper/50">Search the public campaign record.</span>
        </Link>
        <Link to="/ascent" className="group rounded-[var(--radius-md)] border border-paper/10 bg-paper/[0.03] p-5 hover:border-blood/50">
          <Clock3 className="size-5 text-blood" />
          <span className="display mt-4 block text-2xl">Go upward</span>
          <span className="mt-2 block text-sm text-paper/50">Follow the Ascent from ground to orbit.</span>
        </Link>
      </div>
    </Band>
  );
}
