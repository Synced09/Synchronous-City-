import { cn } from "@/lib/utils";

export function PageHero({
  image,
  kicker,
  title,
  lede,
  position = "center",
  tall = false,
}: {
  image: string;
  kicker: string;
  title: string;
  lede?: string;
  position?: string;
  tall?: boolean;
}) {
  return (
    <section
      className={cn(
        "relative isolate overflow-hidden",
        tall ? "min-h-dvh" : "min-h-[72vh]",
      )}
    >
      <img
        src={image}
        alt=""
        className="absolute inset-0 size-full object-cover shift-photo"
        style={{ objectPosition: position }}
      />
      <div className="hero-veil absolute inset-0" />
      <div
        className={cn(
          "hero-copy relative z-10 flex flex-col justify-end px-6 pb-16 pt-28 md:px-12 lg:px-16",
          tall ? "min-h-dvh" : "min-h-[72vh]",
        )}
      >
        <div className="stagger max-w-4xl">
          <p className="kicker text-blood">{kicker}</p>
          <h1 className="display mt-4 text-5xl md:text-7xl">{title}</h1>
          {lede ? (
            <p className="mt-6 max-w-xl text-lg text-paper/80">{lede}</p>
          ) : null}
        </div>
      </div>
    </section>
  );
}
