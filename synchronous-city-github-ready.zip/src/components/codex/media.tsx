import { useLightbox } from "@/components/providers";
import { cn } from "@/lib/utils";

export function Plate({
  src,
  alt,
  caption,
  className,
  position = "center",
  imageClassName,
}: {
  src: string;
  alt: string;
  caption?: string;
  className?: string;
  position?: string;
  imageClassName?: string;
}) {
  const open = useLightbox();
  return (
    <figure className={cn("plate", className)}>
      <button
        type="button"
        onClick={() => open(src, alt)}
        className="block w-full overflow-hidden"
        aria-label={`Expand ${alt}`}
      >
        <img
          src={src}
          alt={alt}
          className={cn("shift-photo max-h-[80vh] w-full object-cover", imageClassName)}
          style={{ objectPosition: position }}
        />
      </button>
      {caption ? (
        <figcaption className="kicker px-4 py-3 text-muted">{caption}</figcaption>
      ) : null}
    </figure>
  );
}
