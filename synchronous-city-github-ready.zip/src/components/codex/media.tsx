import { useLightbox } from "@/components/providers";
import { cn } from "@/lib/utils";

export function Plate({
  src,
  alt,
  caption,
  className,
  position = "center",
}: {
  src: string;
  alt: string;
  caption?: string;
  className?: string;
  position?: string;
}) {
  const open = useLightbox();
  return (
    <figure className={cn("plate", className)}>
      <button
        type="button"
        onClick={() => open(src, alt)}
        className="block w-full overflow-hidden"
        aria-label={`Expand ${alt}`}
      >
        <img
          src={src}
          alt={alt}
          className="shift-photo mx-auto max-h-[80vh] max-w-full object-contain"
          style={{ objectPosition: position }}
        />
      </button>
      {caption ? (
        <figcaption className="kicker px-4 py-3 text-muted">{caption}</figcaption>
      ) : null}
    </figure>
  );
}
