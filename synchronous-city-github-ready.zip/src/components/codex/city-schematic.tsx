import { useMemo, useState } from "react";
import { cn } from "@/lib/utils";

type Zone = "wall" | "water" | "ascent" | "dome" | "gate";

const copy: Record<Zone, { title: string; body: string }> = {
  wall: {
    title: "The Nine Walls",
    body: "A nonagon at civic scale. Each face looks inward toward the Ascent — three shifts, written nine times.",
  },
  water: {
    title: "Inner Waters",
    body: "Concentric canals ring the core. They cool the harvest, carry craft, and keep the dome's climate honest.",
  },
  ascent: {
    title: "Seraphis Ascent",
    body: "The needle at the center. Bloodsteel and white ceramic, crowned by a ring. The only road that goes up.",
  },
  dome: {
    title: "The Dome",
    body: "A held sky. It does not lock the city in so much as keep the Cycle on time.",
  },
  gate: {
    title: "The Southern Gate",
    body: "The formal mouth of the city. Dawnshift opens it like an eyelid. Noctshift keeps a narrower watch.",
  },
};

function regularPolygon(
  n: number,
  cx: number,
  cy: number,
  r: number,
  rot = -Math.PI / 2,
) {
  return Array.from({ length: n }, (_, i) => {
    const a = rot + (i * 2 * Math.PI) / n;
    return `${cx + r * Math.cos(a)},${cy + r * Math.sin(a)}`;
  }).join(" ");
}

export function CitySchematic() {
  const [zone, setZone] = useState<Zone>("ascent");
  const outer = useMemo(() => regularPolygon(9, 200, 216, 172), []);
  const water = useMemo(() => regularPolygon(9, 200, 216, 124), []);
  const core = useMemo(() => regularPolygon(9, 200, 216, 58), []);

  return (
    <div className="grid items-center gap-10 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)]">
      <svg
        viewBox="0 0 400 430"
        className="w-full max-w-lg justify-self-center"
        role="img"
        aria-label="Schematic of Synchronous City as a nonagon"
      >
        <ellipse
          cx="200"
          cy="216"
          rx="186"
          ry="96"
          fill="none"
          stroke="currentColor"
          strokeWidth={zone === "dome" ? 2.2 : 1.1}
          strokeDasharray="5 7"
          opacity={zone === "dome" ? 0.9 : 0.35}
          className="cursor-pointer"
          onClick={() => setZone("dome")}
        />
        <polygon
          points={outer}
          fill="currentColor"
          fillOpacity="0.04"
          stroke="currentColor"
          strokeWidth={zone === "wall" ? 3 : 2}
          className="cursor-pointer"
          onClick={() => setZone("wall")}
        />
        <polygon
          points={water}
          fill="var(--accent)"
          fillOpacity={zone === "water" ? 0.28 : 0.12}
          stroke="var(--accent)"
          strokeWidth="1.4"
          className="cursor-pointer"
          onClick={() => setZone("water")}
        />
        <polygon
          points={core}
          fill="var(--surface)"
          stroke="currentColor"
          strokeWidth="1.2"
        />
        <rect
          x="194"
          y="72"
          width="12"
          height="144"
          rx="1.5"
          fill="var(--accent)"
          className="cursor-pointer"
          onClick={() => setZone("ascent")}
        />
        <circle
          cx="200"
          cy="88"
          r="26"
          fill="none"
          stroke="var(--accent)"
          strokeWidth={zone === "ascent" ? 2.4 : 1.6}
          className="cursor-pointer"
          onClick={() => setZone("ascent")}
        />
        <circle cx="200" cy="216" r="4" fill="var(--accent)" />
        <path
          d="M176 384 L200 412 L224 384"
          fill="none"
          stroke="currentColor"
          strokeWidth={zone === "gate" ? 3 : 2}
          className="cursor-pointer"
          onClick={() => setZone("gate")}
        />
      </svg>
      <div>
        <p className="kicker text-blood">Plan of the dome</p>
        <div className="mt-4 flex flex-wrap gap-2">
          {(Object.keys(copy) as Zone[]).map((id) => (
            <button
              key={id}
              type="button"
              onClick={() => setZone(id)}
              className={cn(
                "kicker h-10 rounded-full px-3",
                zone === id ? "bg-blood text-paper" : "border border-line text-muted",
              )}
            >
              {copy[id].title}
            </button>
          ))}
        </div>
        <h3 className="display mt-8 text-4xl">{copy[zone].title}</h3>
        <p className="mt-4 max-w-md text-muted">{copy[zone].body}</p>
      </div>
    </div>
  );
}
