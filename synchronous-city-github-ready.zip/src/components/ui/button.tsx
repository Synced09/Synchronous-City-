import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 font-medium tracking-[0.14em] uppercase text-[0.68rem] transition-[background-color,color,border-color,transform,opacity] duration-150 ease-out focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blood disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96]",
  {
    variants: {
      variant: {
        primary: "bg-blood text-paper hover:bg-blood-deep",
        ink: "bg-fg text-bg hover:opacity-90",
        outline:
          "border border-line bg-transparent text-fg hover:border-fg/40 hover:bg-surface",
        ghost: "bg-transparent text-fg hover:bg-surface",
        paper: "bg-paper text-ink hover:bg-paper-2",
      },
      size: {
        sm: "h-10 px-4 rounded-[var(--radius-sm)]",
        md: "h-11 px-5 rounded-[var(--radius-sm)]",
        lg: "h-12 px-6 rounded-[var(--radius-md)]",
      },
    },
    defaultVariants: {
      variant: "primary",
      size: "md",
    },
  },
);

export function Button({
  className,
  variant,
  size,
  asChild = false,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants> & { asChild?: boolean }) {
  const Comp = asChild ? Slot : "button";
  return (
    <Comp className={cn(buttonVariants({ variant, size }), className)} {...props} />
  );
}
