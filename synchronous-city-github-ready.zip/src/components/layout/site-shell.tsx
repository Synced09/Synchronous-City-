import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { Wordmark } from "@/components/logo";
import { ShiftSwitch } from "@/components/codex/shift-switch";
import { city, nav } from "@/lib/campaign";
import { cn } from "@/lib/utils";

function pathIsActive(pathname: string, to: string) {
  if (to === "/") return pathname === "/";
  return pathname === to || pathname.startsWith(`${to}/`);
}

export function SiteShell({ children }: { children: ReactNode }) {
  const [solid, setSolid] = useState(false);
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <a
        href="#content"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:bg-blood focus:px-4 focus:py-2 focus:text-paper"
      >
        Skip to content
      </a>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-30 transition-[background-color,color,border-color] duration-300",
          solid || open
            ? "border-b border-line bg-bg text-fg"
            : "border-b border-transparent text-paper",
        )}
      >
        <div className="flex items-center justify-between gap-4 px-4 py-3 md:px-8">
          <Link to="/" aria-label="Synchronous City home" className="shrink-0">
            <Wordmark />
          </Link>
          <nav className="hidden items-center gap-6 lg:flex" aria-label="Primary">
            {nav.map((item) => {
              const active = pathIsActive(pathname, item.to);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "kicker py-2 transition-colors duration-150",
                    active ? "text-blood" : "text-current/70 hover:text-current",
                  )}
                  aria-current={active ? "page" : undefined}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
          <div className="flex items-center gap-2">
            <div className="hidden sm:block">
              <ShiftSwitch compact />
            </div>
            <button
              type="button"
              className="inline-flex size-11 items-center justify-center rounded-[var(--radius-sm)] lg:hidden"
              aria-label={open ? "Close menu" : "Open menu"}
              aria-expanded={open}
              onClick={() => setOpen((v) => !v)}
            >
              {open ? <X className="size-5" /> : <Menu className="size-5" />}
            </button>
          </div>
        </div>
      </header>

      {open ? (
        <div className="fixed inset-0 z-20 bg-bg pt-20 text-fg lg:hidden">
          <nav className="flex flex-col px-6 py-6" aria-label="Mobile">
            {nav.map((item) => {
              const active = pathIsActive(pathname, item.to);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "border-b border-line py-4 font-display text-3xl",
                    active && "text-blood",
                  )}
                  aria-current={active ? "page" : undefined}
                  onClick={() => setOpen(false)}
                >
                  {item.label}
                </Link>
              );
            })}
            <div className="pt-8">
              <ShiftSwitch />
            </div>
          </nav>
        </div>
      ) : null}

      <main id="content">{children}</main>

      <footer className="border-t border-line bg-surface px-6 py-14 md:px-12 lg:px-16">
        <div className="mx-auto flex max-w-6xl flex-col gap-10 md:flex-row md:items-end md:justify-between">
          <div>
            <Wordmark />
            <p className="mt-4 max-w-sm text-sm text-muted">
              {city.slogan}. Campaign codex, revision {city.revision} — entries in
              flux as the world is still being written.
            </p>
          </div>
          <div className="flex flex-col gap-3 md:items-end md:text-right">
            <p className="font-display text-2xl italic text-fg/90">{city.motto}</p>
            <p className="kicker text-muted">Security Division · Cycle Guardians</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
