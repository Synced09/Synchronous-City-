import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { shiftFromHour, type ShiftId } from "@/lib/campaign";

type ShiftMode = "live" | "lock";

type ShiftContextValue = {
  shift: ShiftId;
  mode: ShiftMode;
  setShift: (id: ShiftId) => void;
  followLive: () => void;
};

const ShiftContext = createContext<ShiftContextValue | null>(null);

const STORAGE_KEY = "sync-city-shift";

function readStored(): { mode: ShiftMode; shift: ShiftId } | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { mode?: ShiftMode; shift?: ShiftId };
    if (parsed.mode === "lock" && parsed.shift) {
      return { mode: "lock", shift: parsed.shift };
    }
    return { mode: "live", shift: shiftFromHour(new Date().getHours()) };
  } catch {
    return null;
  }
}

export function AppProviders({ children }: { children: ReactNode }) {
  const [mode, setMode] = useState<ShiftMode>("live");
  const [shift, setShiftState] = useState<ShiftId>(() =>
    shiftFromHour(new Date().getHours()),
  );
  const [lightbox, setLightbox] = useState<{ src: string; alt: string } | null>(null);

  useEffect(() => {
    const stored = readStored();
    if (stored) {
      setMode(stored.mode);
      setShiftState(stored.shift);
    }
  }, []);

  useEffect(() => {
    document.documentElement.dataset.shift = shift;
  }, [shift]);

  useEffect(() => {
    if (mode !== "live") return;
    const tick = () => setShiftState(shiftFromHour(new Date().getHours()));
    tick();
    const id = window.setInterval(tick, 60_000);
    return () => window.clearInterval(id);
  }, [mode]);

  const setShift = useCallback((id: ShiftId) => {
    setMode("lock");
    setShiftState(id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ mode: "lock", shift: id }));
  }, []);

  const followLive = useCallback(() => {
    const next = shiftFromHour(new Date().getHours());
    setMode("live");
    setShiftState(next);
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ mode: "live" }));
  }, []);

  const shiftValue = useMemo(
    () => ({ shift, mode, setShift, followLive }),
    [shift, mode, setShift, followLive],
  );

  const openLightbox = useCallback((src: string, alt: string) => {
    setLightbox({ src, alt });
  }, []);

  const closeLightbox = useCallback(() => setLightbox(null), []);

  useEffect(() => {
    if (!lightbox) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeLightbox();
    };
    window.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [lightbox, closeLightbox]);

  return (
    <ShiftContext.Provider value={shiftValue}>
      <LightboxContext.Provider value={openLightbox}>
        {children}
        <div className="grain" aria-hidden="true" />
        {lightbox ? (
          <button
            type="button"
            className="fixed inset-0 z-50 flex items-center justify-center bg-ink/92 p-4 md:p-10"
            onClick={closeLightbox}
            aria-label="Close image"
          >
            <img
              src={lightbox.src}
              alt={lightbox.alt}
              className="max-h-full max-w-full object-contain"
              onClick={(e) => e.stopPropagation()}
            />
          </button>
        ) : null}
      </LightboxContext.Provider>
    </ShiftContext.Provider>
  );
}

export function useShift() {
  const ctx = useContext(ShiftContext);
  if (!ctx) throw new Error("useShift must be used within AppProviders");
  return ctx;
}

const LightboxContext = createContext<((src: string, alt: string) => void) | null>(
  null,
);

export function useLightbox() {
  const ctx = useContext(LightboxContext);
  if (!ctx) throw new Error("useLightbox must be used within AppProviders");
  return ctx;
}
