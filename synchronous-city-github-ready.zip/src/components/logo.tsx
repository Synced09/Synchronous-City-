import { cn } from "@/lib/utils";

export function Mark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 64 96"
      className={cn("block", className)}
      fill="none"
      aria-hidden="true"
    >
      <g
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <circle cx="32" cy="38" r="14" />
        <path d="M32 4v88" />
        <path d="M10 38h44" />
        <path d="M32 24v28" opacity="0.55" />
      </g>
      <path d="M32 4 L35.2 16 L32 19 L28.8 16 Z" fill="currentColor" />
      <circle cx="32" cy="38" r="2.2" fill="currentColor" />
    </svg>
  );
}

export function Wordmark({ className }: { className?: string }) {
  return (
    <span className={cn("flex items-center gap-3", className)}>
      <Mark className="h-9 w-6 text-blood" />
      <span className="flex flex-col leading-none">
        <span className="kicker text-[0.6rem] text-current">Synchronous</span>
        <span className="font-display text-xl tracking-tight">City</span>
      </span>
    </span>
  );
}
