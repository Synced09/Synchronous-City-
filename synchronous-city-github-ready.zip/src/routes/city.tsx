import { createFileRoute } from "@tanstack/react-router";
import { CitySchematic } from "@/components/codex/city-schematic";
import { PageHero } from "@/components/codex/page-hero";
import { Band, Reveal } from "@/components/codex/reveal";
import { Plate } from "@/components/codex/media";
import { useShift } from "@/components/providers";
import { art, city, shiftOrder, shifts } from "@/lib/campaign";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/city")({ component: CityPage });

function CityPage() {
  const { shift, setShift } = useShift();

  return (
    <div className="page-enter">
      <PageHero
        image={art.city}
        kicker="The City-State"
        title="Synchronous City"
        lede="A nonagonal metropolis under glass. Twenty to thirty million lives, kept in time."
        position="center 40%"
      />

      <Band>
        <Reveal>
          <p className="kicker text-blood">Overview</p>
          <h2 className="display mt-4 max-w-3xl text-4xl md:text-5xl">
            One people. One cycle. One tomorrow.
          </h2>
          <div className="mt-8 grid gap-8 md:grid-cols-2">
            <p className="text-muted">
              Fifty to eighty kilometers across, the city sits on a plateau some
              two thousand meters at its heart. A transparent dome holds the
              weather to the Cycle. What looks like luxury from the air is a
              civic machine: harvest from the Blood Biome, industry at Solshift,
              dreams after dark.
            </p>
            <p className="text-muted">
              The geometry is the law. Nine walls face the Seraphis Ascent. Three
              shifts divide the day. Shops, vendors, and venues do not close so
              much as become someone else when the hour turns.
            </p>
          </div>
        </Reveal>
        <dl className="mt-14 grid grid-cols-2 gap-6 md:grid-cols-4">
          {city.stats.map((stat) => (
            <div key={stat.label}>
              <dt className="kicker text-muted">{stat.label}</dt>
              <dd className="display mt-2 text-3xl">{stat.value}</dd>
              <p className="mt-2 text-sm text-muted">{stat.detail}</p>
            </div>
          ))}
        </dl>
      </Band>

      <Band className="bg-surface">
        <Reveal>
          <CitySchematic />
        </Reveal>
      </Band>

      <Band>
        <Reveal>
          <p className="kicker text-blood">The Three Shifts</p>
          <h2 className="display mt-4 text-4xl md:text-5xl">A day in three movements.</h2>
        </Reveal>
        <div className="mt-12 space-y-4">
          {shiftOrder.map((id) => {
            const s = shifts[id];
            const active = shift === id;
            return (
              <button
                key={id}
                type="button"
                onClick={() => setShift(id)}
                className={cn(
                  "plate w-full p-6 text-left md:p-8",
                  active && "border-blood/50",
                )}
              >
                <div className="flex flex-wrap items-baseline justify-between gap-3">
                  <h3 className="display text-3xl">{s.name}</h3>
                  <span className="kicker text-muted">{s.hours}</span>
                </div>
                <p className="mt-4 max-w-2xl text-muted">{s.focus}</p>
                <ul className="mt-5 flex flex-wrap gap-2">
                  {s.notes.map((n) => (
                    <li
                      key={n}
                      className="kicker rounded-full border border-line px-3 py-2 text-muted"
                    >
                      {n}
                    </li>
                  ))}
                </ul>
              </button>
            );
          })}
        </div>
      </Band>

      <Band>
        <div className="grid items-start gap-10 lg:grid-cols-2">
          <Reveal>
            <p className="kicker text-blood">From the terrace</p>
            <h2 className="display mt-4 text-4xl">A city in harmony with nature, built for eternity.</h2>
            <p className="mt-6 text-muted">
              Beyond the walls, water and red autumn hills. The Bishop's Ring
              waits above. Inside: plazas of white ceramic, wet enough to hold
              the sky, striped with bloodsteel the way a body is striped with
              veins.
            </p>
          </Reveal>
          <Plate
            src={art.ascentMid}
            alt="Seraphis Ascent above the clouds"
            caption="The climb, looking out"
          />
        </div>
      </Band>
    </div>
  );
}
