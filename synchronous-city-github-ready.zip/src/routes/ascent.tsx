import { createFileRoute } from "@tanstack/react-router";
import { Band, Reveal } from "@/components/codex/reveal";
import { Plate } from "@/components/codex/media";
import { art, city, infrastructure } from "@/lib/campaign";

export const Route = createFileRoute("/ascent")({ component: AscentPage });

const beats = [
  {
    image: art.city,
    kicker: "Ground",
    title: "The city holds its breath.",
    body: "From the southern gate the Ascent is a needle. Nonagon walls, inner water, a dome like a held sky. Everyone in Sync City lives in relation to this line.",
    position: "center 45%",
  },
  {
    image: art.ascentBase,
    kicker: "Threshold",
    title: "Seraphis Ascent",
    body: "White ceramic, bloodsteel ribs, crimson banners on the ascent structure. The inscription is not decoration. It is the fare.",
    position: "center 60%",
  },
  {
    image: art.ascentMid,
    kicker: "The climb",
    title: city.ascentMotto,
    body: "Capsules run the spine. Cloud deck below; the orbital complex still out of frame. Height here is not escape. It is proximity.",
    position: "center",
  },
  {
    image: art.wings,
    kicker: "Orbit",
    title: "Seraphim's Wings Orbital Complex",
    body: "A vast orbital complex of white wings and Bloodsteel, anchored in space and connected directly to the surface. The bridge between worlds. The future is not far.",
    position: "center",
  },
];

function AscentPage() {
  return (
    <div className="page-enter">
      {beats.map((beat) => (
        <section
          key={beat.kicker}
          className="relative isolate min-h-dvh overflow-hidden"
        >
          <img
            src={beat.image}
            alt=""
            className="absolute inset-0 size-full object-cover shift-photo"
            style={{ objectPosition: beat.position }}
          />
          <div className="hero-veil absolute inset-0" />
          <div className="hero-copy relative z-10 mx-auto flex min-h-dvh max-w-6xl flex-col justify-end px-6 py-20 md:px-12">
            <p className="kicker">{beat.kicker}</p>
            <h1 className="display mt-4 max-w-3xl text-4xl md:text-6xl">{beat.title}</h1>
            <p className="mt-6 max-w-xl text-lg text-paper/80">{beat.body}</p>
          </div>
        </section>
      ))}

      <Band>
        <Reveal>
          <p className="kicker text-blood">Materials & infrastructure</p>
          <h2 className="display mt-4 text-4xl md:text-5xl">What the climb is made of.</h2>
        </Reveal>
        <div className="mt-12 grid gap-4 md:grid-cols-3">
          {infrastructure.map((item, i) => (
            <Reveal key={item.id} delay={i * 70}>
              <article className="plate h-full p-6">
                <h3 className="display text-2xl">{item.title}</h3>
                <p className="mt-4 text-sm text-muted">{item.body}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </Band>

      <Band className="bg-surface">
        <div className="grid gap-6 lg:grid-cols-2">
          <Plate
            src={art.ascentBase}
            alt="Base of the Seraphis Ascent"
            caption="Threshold — looking up"
          />
          <Plate
            src={art.wings}
            alt="Seraphim's Wings Orbital Complex from orbit"
            caption="Seraphim's Wings — the bridge between worlds"
          />
        </div>
      </Band>
    </div>
  );
}
