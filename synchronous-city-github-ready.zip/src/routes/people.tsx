import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHero } from "@/components/codex/page-hero";
import { Band, Reveal } from "@/components/codex/reveal";
import { Plate } from "@/components/codex/media";
import { art, city, people } from "@/lib/campaign";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/people")({ component: PeoplePage });

function PeoplePage() {
  const [openId, setOpenId] = useState<(typeof people)[number]["id"]>("seraphrunner");
  const selected = people.find((p) => p.id === openId) ?? people[0]!;

  return (
    <div className="page-enter">
      <PageHero
        key={selected.id}
        image={selected.hero}
        kicker="Player Characters"
        title={selected.role}
        lede={selected.summary}
        position="center top"
        tall
      />

      <Band>
        <div className="flex flex-wrap gap-2">
          {people.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => {
                setOpenId(p.id);
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
              className={cn(
                "kicker h-11 rounded-full px-5",
                p.id === openId ? "bg-blood text-paper" : "border border-line text-muted",
              )}
            >
              {p.role}
            </button>
          ))}
        </div>

        <div className="mt-14 grid items-start gap-12 lg:grid-cols-[0.9fr_1.1fr]">
          <Reveal>
            <p className="kicker text-blood">{selected.division}</p>
            <h2 className="display mt-4 text-4xl md:text-5xl">{selected.creed}</h2>
            <blockquote className="mt-8 border-l border-blood pl-5 font-display text-2xl italic">
              {selected.quote}
            </blockquote>
            <ul className="mt-10 space-y-8">
              {selected.details.map((d) => (
                <li key={d.title}>
                  <h3 className="kicker text-fg">{d.title}</h3>
                  <p className="mt-2 text-muted">{d.body}</p>
                </li>
              ))}
            </ul>
            {selected.id === "warden" ? (
              <p className="kicker mt-10 text-muted">{city.wardenCreed.join(" · ")}</p>
            ) : (
              <p className="kicker mt-10 text-muted">{city.motto}</p>
            )}
          </Reveal>
          <div className="grid gap-4">
            <Plate src={selected.portrait} alt={`${selected.role} close study`} />
            {"vestments" in selected && selected.vestments ? (
              <div className="grid gap-4 sm:grid-cols-2">
                {selected.vestments.map((v) => (
                  <Plate key={v.name} src={v.image} alt={v.name} caption={v.note} />
                ))}
              </div>
            ) : (
              <Plate
                src={art.officerHero}
                alt="Seraphrunner officer on the plaza"
                caption="The coat conceals the armor, until it is needed."
                position="center top"
              />
            )}
          </div>
        </div>
      </Band>

      <Band className="bg-surface">
        <Reveal>
          <p className="kicker text-blood">Field plate</p>
          <h2 className="display mt-3 text-3xl">Original study board</h2>
          <p className="mt-3 max-w-xl text-sm text-muted">
            Uncropped concept plate, kept for campaign reference. Tap to enlarge.
          </p>
        </Reveal>
        <div className="mt-8">
          <Plate
            src={selected.plate}
            alt={`${selected.role} full concept plate`}
            caption={`${selected.role} — field archive`}
          />
        </div>
      </Band>
    </div>
  );
}
