import { createRootRoute, HeadContent, Link, Outlet, Scripts } from "@tanstack/react-router";
import { AppProviders } from "@/components/providers";
import { SiteShell } from "@/components/layout/site-shell";
import appCss from "../styles.css?url";

const APP_NAME = "Synchronous City";

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: APP_NAME },
      {
        name: "description",
        content:
          "Campaign codex for Synchronous City — one people, one cycle, one tomorrow.",
      },
      { name: "theme-color", content: "#08090c" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: `${import.meta.env.BASE_URL}favicon.svg` },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600&family=Outfit:wght@300;400;500;600;700&display=swap",
      },
      { rel: "stylesheet", href: appCss },
    ],
  }),
  notFoundComponent: NotFound,
  component: RootDocument,
});

function NotFound() {
  return (
    <div className="page-enter mx-auto max-w-2xl px-6 py-32 text-center">
      <p className="kicker text-blood">Off roster</p>
      <h1 className="display mt-4 text-5xl">This hour is not on the Cycle.</h1>
      <p className="mt-4 text-muted">The path you asked for has not been catalogued.</p>
      <Link to="/" className="kicker mt-8 inline-block text-blood">
        Return to the Codex
      </Link>
    </div>
  );
}

function RootDocument() {
  return (
    <html lang="en" suppressHydrationWarning className="antialiased" data-shift="sol">
      <head>
        <HeadContent />
      </head>
      <body>
        <AppProviders>
          <SiteShell>
            <Outlet />
          </SiteShell>
        </AppProviders>
        <Scripts />
      </body>
    </html>
  );
}
