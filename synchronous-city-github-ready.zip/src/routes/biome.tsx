import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/codex/page-hero";
import { Band, Reveal } from "@/components/codex/reveal";
import { Plate } from "@/components/codex/media";
import { art, biome } from "@/lib/campaign";

export const Route = createFileRoute("/biome")({ component: BiomePage });

function BiomePage() {
  return (
    <div className="page-enter">
      <PageHero
        image={art.bloodgrass}
        kicker="The Outer World"
        title="Blood Biome"
        lede={biome.lede}
        position="center"
      />

      <Band>
        <div className="grid gap-6 md:grid-cols-3">
          {biome.points.map((p, i) => (
            <Reveal key={p.title} delay={i * 80}>
              <article className="plate h-full p-6">
                <h2 className="display text-2xl">{p.title}</h2>
                <p className="mt-4 text-sm text-muted">{p.body}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </Band>

      <Band className="bg-surface">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <Plate
            src={art.bloodgrass}
            alt="Bloodgrass fields with the city on the horizon"
            caption="Bloodgrass Fields — harvest in the wind"
          />
          <Reveal>
            <p className="kicker text-blood">Bloodgrass Fields</p>
            <h2 className="display mt-4 text-4xl md:text-5xl">
              The city drinks from the red.
            </h2>
            <ul className="mt-8 space-y-4 text-muted">
              {biome.grass.map((line) => (
                <li key={line} className="border-l border-blood pl-4">
                  {line}
                </li>
              ))}
            </ul>
          </Reveal>
        </div>
      </Band>

      <Band>
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <Reveal>
            <p className="kicker text-blood">Bioengineered fauna</p>
            <h2 className="display mt-4 text-4xl">{biome.bunnies.title}</h2>
            <p className="mt-6 text-muted">{biome.bunnies.body}</p>
          </Reveal>
          <Plate
            src={art.bunny}
            alt="A red energy-storing bunny in bloodgrass"
            caption="Red Bunny — store, release, balance"
          />
        </div>
      </Band>

      <Band className="bg-surface">
        <Reveal>
          <p className="kicker text-blood">Cultural role of red</p>
          <h2 className="display mt-4 max-w-3xl text-4xl md:text-5xl">
            {biome.red.symbolism}
          </h2>
          <p className="mt-6 max-w-2xl text-muted">{biome.red.aesthetics}</p>
        </Reveal>
      </Band>
    </div>
  );
}
