import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight, ChevronRight, CircleDot, Database, Radio, ScanLine } from "lucide-react";
import { Mark } from "@/components/logo";
import { Band, Reveal } from "@/components/codex/reveal";
import { useShift } from "@/components/providers";
import { PlayerConsole } from "@/components/codex/player-console";
import { art, archive, city, people, runner, shiftOrder, shifts } from "@/lib/campaign";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const { shift } = useShift();
  const active = shifts[shift];
  const featured = archive.slice(0, 6);

  return (
    <div className="page-enter sync-home">
      <section className="sync-hero relative isolate min-h-dvh overflow-hidden bg-ink text-paper">
        <img src={art.city} alt="Synchronous City beneath its dome" className="absolute inset-0 size-full object-cover sync-hero-image" />
        <div className="sync-grid absolute inset-0" />
        <div className="sync-hero-glow absolute inset-0" />
        <div className="relative z-10 mx-auto flex min-h-dvh max-w-[1500px] flex-col justify-between px-5 pb-8 pt-28 md:px-10 md:pb-10">
          <div className="flex items-start justify-between gap-6">
            <div className="flex items-center gap-3">
              <span className="sync-status-dot" />
              <span className="kicker text-paper/65">CIVIC INFORMATION NETWORK · ONLINE</span>
            </div>
            <div className="hidden text-right md:block">
              <p className="kicker text-paper/45">LOCAL NODE</p>
              <p className="mt-1 font-mono text-xs text-paper/80">SYN-3090 / 01</p>
            </div>
          </div>

          <div className="grid gap-10 lg:grid-cols-[1.2fr_.8fr] lg:items-end">
            <div>
              <div className="mb-7 flex items-center gap-4">
                <Mark className="h-16 w-10 text-blood md:h-20 md:w-12" />
                <div className="hairline w-24 bg-paper/25" />
                <span className="kicker text-paper/50">CYCLE {active.name.toUpperCase()}</span>
              </div>
              <p className="kicker text-blood">Synchronous City · Year 3090</p>
              <h1 className="sync-title mt-4 max-w-5xl text-6xl md:text-8xl xl:text-[9rem]">Synchronous City</h1>
              <p className="mt-6 max-w-xl text-base leading-7 text-paper/65 md:text-lg">
                One people. One cycle. One living system. Access the public record of the city beneath the dome.
              </p>
              <div className="mt-9 flex flex-wrap gap-3">
                <Link to="/city" className="sync-command sync-command-primary">
                  <ScanLine className="size-4" /> Enter city network <ArrowUpRight className="size-4" />
                </Link>
                <Link to="/archive" className="sync-command">
                  <Database className="size-4" /> Browse recovered records
                </Link>
              </div>
            </div>

            <div className="sync-cycle-panel">
              <div className="flex items-center justify-between border-b border-paper/10 px-5 py-4">
                <span className="kicker text-paper/45">CURRENT CYCLE</span>
                <Radio className="size-4 text-blood" />
              </div>
              <div className="p-5">
                <p className="font-display text-4xl">{active.name}</p>
                <p className="mt-2 text-sm text-paper/55">{active.hours} · {active.motto}</p>
                <div className="mt-6 grid grid-cols-3 gap-2">
                  {shiftOrder.map((id) => (
                    <Link key={id} to="/city" className={`sync-mini-shift ${id === shift ? "is-active" : ""}`}>
                      <span>{shifts[id].name.replace("shift", "")}</span>
                      <small>{shifts[id].window}</small>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-end justify-between gap-5 pt-10">
            <div className="hidden md:block">
              <p className="kicker text-paper/35">CITY SYSTEMS</p>
              <p className="mt-2 font-mono text-xs text-paper/55">BIOENERGY // BLOODSTEEL // SYNCHRONIZATION // ORBITAL ACCESS</p>
            </div>
            <div className="ml-auto flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.24em] text-paper/35">
              <CircleDot className="size-3" /> Node stable
            </div>
          </div>
        </div>
      </section>

      <section className="sync-marquee border-b border-line bg-bg py-3 overflow-hidden">
        <div className="sync-marquee-track">
          <span>THE CITY INHALES</span><i>◆</i><span>THE CITY WORKS</span><i>◆</i><span>THE CITY REMEMBERS</span><i>◆</i>
          <span>THE CITY INHALES</span><i>◆</i><span>THE CITY WORKS</span><i>◆</i><span>THE CITY REMEMBERS</span><i>◆</i>
        </div>
      </section>

      <Band className="sync-interface-band">
        <div className="sync-section-head">
          <div>
            <p className="kicker text-blood">Public terminal</p>
            <h2 className="display mt-3 text-4xl md:text-6xl">A city you can navigate.</h2>
          </div>
          <p className="max-w-md text-sm leading-6 text-muted">The Codex is not a wiki. It is a window into a functioning civilization. Follow the Cycle, open records, and let the world reveal itself in pieces.</p>
        </div>

        <div className="sync-module-grid mt-12">
          <Link to="/city" className="sync-module sync-module-large group">
            <img src={art.city} alt="Synchronous City" className="absolute inset-0 size-full object-cover" />
            <div className="sync-module-shade absolute inset-0" />
            <div className="relative z-10 flex h-full flex-col justify-between p-6 md:p-8">
              <div className="flex justify-between"><span className="kicker text-paper/60">01 · CITY</span><ArrowUpRight className="size-5 text-paper/50 transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" /></div>
              <div><p className="font-mono text-[10px] tracking-[.22em] text-paper/45">NONAGON / 50–80 KM / 20–30M</p><h3 className="display mt-2 text-4xl text-paper md:text-6xl">The living machine.</h3></div>
            </div>
          </Link>
          <Link to="/biome" className="sync-module group bg-[#101316]">
            <img src={art.bloodgrass} alt="Bloodgrass Fields" className="absolute inset-0 size-full object-cover opacity-70 transition duration-700 group-hover:scale-105" />
            <div className="sync-module-shade absolute inset-0" />
            <div className="relative z-10 flex h-full flex-col justify-between p-6 md:p-7"><div className="flex justify-between"><span className="kicker text-paper/60">02 · BIOME</span><ArrowUpRight className="size-5 text-paper/50" /></div><h3 className="display text-4xl text-paper">Blood Biome</h3></div>
          </Link>
          <Link to="/ascent" className="sync-module group bg-[#101316]">
            <img src={art.ascentBase} alt="Seraphis Ascent" className="absolute inset-0 size-full object-cover opacity-70 transition duration-700 group-hover:scale-105" />
            <div className="sync-module-shade absolute inset-0" />
            <div className="relative z-10 flex h-full flex-col justify-between p-6 md:p-7"><div className="flex justify-between"><span className="kicker text-paper/60">03 · ORBIT</span><ArrowUpRight className="size-5 text-paper/50" /></div><h3 className="display text-4xl text-paper">Seraphis Ascent</h3></div>
          </Link>
        </div>
      </Band>

      <section className="border-y border-line bg-surface">
        <div className="mx-auto grid max-w-6xl gap-0 lg:grid-cols-[.7fr_1.3fr]">
          <div className="border-b border-line p-6 md:p-10 lg:border-b-0 lg:border-r">
            <p className="kicker text-blood">Recovered shelf</p>
            <h2 className="display mt-3 text-4xl md:text-5xl">Records in circulation.</h2>
            <p className="mt-5 text-sm leading-6 text-muted">Some are civic documents. Some are field observations. The difference may become important.</p>
            <Link to="/archive" className="kicker mt-8 inline-flex items-center gap-2 text-blood">Open archive <ChevronRight className="size-4" /></Link>
          </div>
          <div className="grid md:grid-cols-2">
            {featured.map((entry, index) => (
              <Link key={entry.id} to={entry.href ?? "/archive"} className="sync-record group border-b border-line p-6 transition-colors hover:bg-bg md:p-8">
                <div className="flex items-center justify-between"><span className="font-mono text-[10px] tracking-[.18em] text-muted">{String(index + 1).padStart(2, "0")} / {entry.category}</span><ChevronRight className="size-4 text-muted transition-transform group-hover:translate-x-1" /></div>
                <h3 className="mt-8 font-display text-2xl">{entry.title}</h3>
                <p className="mt-2 text-sm leading-6 text-muted">{entry.summary}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <PlayerConsole />

      <section className="relative overflow-hidden bg-ink px-6 py-24 text-paper md:px-12 md:py-32">
        <div className="absolute inset-0 opacity-30"><img src={art.ring} alt="Bishop's Ring" className="size-full object-cover" /></div>
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/70 to-ink/20" />
        <div className="relative z-10 mx-auto max-w-6xl">
          <p className="kicker text-blood">Above the dome</p>
          <h2 className="display mt-4 max-w-4xl text-5xl md:text-7xl">The future is not far. It is above you.</h2>
          <p className="mt-6 max-w-xl text-paper/55">Bloodsteel reaches from the city into orbit. The Seraphis Ascent is the line between them.</p>
          <Link to="/ascent" className="sync-command sync-command-primary mt-9 inline-flex">Access orbital infrastructure <ArrowUpRight className="size-4" /></Link>
        </div>
      </section>
    </div>
  );
}
