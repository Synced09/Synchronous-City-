import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/codex/page-hero";
import { Band, Reveal } from "@/components/codex/reveal";
import { Plate } from "@/components/codex/media";
import { art, runner } from "@/lib/campaign";

export const Route = createFileRoute("/fleet")({ component: FleetPage });

function FleetPage() {
  return (
    <div className="page-enter">
      <PageHero
        image={art.runnerPlate}
        kicker="Security Division Fleet"
        title={runner.name}
        lede={runner.lede}
        position="center 18%"
      />

      <Band>
        <Reveal>
          <p className="kicker text-blood">Key features</p>
          <h2 className="display mt-4 text-4xl md:text-5xl">Silent. Precise. Divine.</h2>
        </Reveal>
        <div className="mt-12 grid gap-4 md:grid-cols-2">
          {runner.features.map((f, i) => (
            <Reveal key={f.title} delay={i * 70}>
              <article className="plate h-full p-6 md:p-8">
                <h3 className="display text-2xl">{f.title}</h3>
                <p className="mt-4 text-muted">{f.body}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </Band>

      <Band className="bg-surface">
        <div className="grid items-center gap-10 lg:grid-cols-2">
          <Plate
            src={art.runnerSide}
            alt="Seraph Runner side profile"
            caption="Side elevation — carbon fiber and Bloodsteel"
          />
          <Reveal>
            <p className="kicker text-blood">In motion</p>
            <h2 className="display mt-4 text-4xl">{runner.motto}</h2>
            <p className="mt-6 text-muted">
              Halo for status. Rim light when the magnets wake. The machine is
              not a civilian toy — it is how a Seraphrunner outruns a broken
              hour.
            </p>
            <Plate
              src={art.runnerMotion}
              alt="Seraph Runner at speed"
              caption="Active ride"
              className="mt-8"
            />
          </Reveal>
        </div>
      </Band>

      <Band>
        <Reveal>
          <p className="kicker text-blood">Field plate</p>
          <h2 className="display mt-3 text-3xl">Full machine study</h2>
        </Reveal>
        <div className="mt-8">
          <Plate
            src={runner.plate}
            alt="Seraph Runner concept plate"
            caption="Faster / Higher / Together"
          />
        </div>
      </Band>
    </div>
  );
}
