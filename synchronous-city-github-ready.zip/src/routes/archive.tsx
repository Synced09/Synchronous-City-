import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHero } from "@/components/codex/page-hero";
import { Band } from "@/components/codex/reveal";
import { art, archive, type ArchiveCategory } from "@/lib/campaign";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/archive")({ component: ArchivePage });

const categories: Array<ArchiveCategory | "All"> = [
  "All",
  "City",
  "Cycle",
  "Biome",
  "People",
  "Fleet",
  "Infrastructure",
];

function ArchivePage() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<(typeof categories)[number]>("All");

  const filtered = useMemo(() => {
    const query = q.trim().toLowerCase();
    return archive.filter((e) => {
      if (cat !== "All" && e.category !== cat) return false;
      if (!query) return true;
      const hay = `${e.title} ${e.summary} ${e.body} ${e.category} ${e.id} ${e.keys?.join(" ") ?? ""}`.toLowerCase();
      if (hay.includes(query)) return true;
      return hay.split(/[^a-z0-9]+/).some((word) => word.startsWith(query));
    });
  }, [q, cat]);

  return (
    <div className="page-enter">
      <PageHero
        image={art.city}
        kicker="Living Document"
        title="Field Archive"
        lede="Search the campaign bible. This codex is in revision — new plates will land as the world is written."
      />

      <Band>
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <label className="block w-full max-w-md">
            <span className="kicker text-muted">Search entries</span>
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Bloodsteel, Warden, Dawnshift…"
              className="mt-2 h-12 w-full rounded-[var(--radius-md)] border border-line bg-surface px-4 text-fg placeholder:text-muted/70 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blood"
            />
          </label>
          <a
            href={`${import.meta.env.BASE_URL}campaign/codex-reference.pdf`}
            className="kicker inline-flex h-12 items-center self-start rounded-[var(--radius-sm)] border border-line px-4 text-muted hover:text-fg md:self-end"
          >
            Download reference PDF
          </a>
        </div>

        <div className="mt-8 flex flex-wrap gap-2">
          {categories.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => setCat(c)}
              className={cn(
                "kicker h-10 rounded-full px-4",
                cat === c ? "bg-blood text-paper" : "border border-line text-muted",
              )}
            >
              {c}
            </button>
          ))}
        </div>

        <p className="kicker mt-8 text-muted tabular-nums">
          {filtered.length} {filtered.length === 1 ? "entry" : "entries"}
        </p>

        {filtered.length === 0 ? (
          <p className="mt-10 max-w-md text-muted">
            No entries match. Try another shift of the language — or clear the
            search.
          </p>
        ) : (
          <ul className="mt-8 grid gap-4 md:grid-cols-2">
            {filtered.map((entry) => (
              <li key={entry.id} className="plate p-6">
                <p className="kicker text-blood">{entry.category}</p>
                <h2 className="display mt-3 text-2xl">{entry.title}</h2>
                <p className="mt-3 text-sm text-muted">{entry.summary}</p>
                <p className="mt-4 text-sm text-fg/80">{entry.body}</p>
                {entry.href ? (
                  <Link
                    to={entry.href}
                    className="kicker mt-6 inline-block text-blood"
                  >
                    Open in Codex
                  </Link>
                ) : null}
              </li>
            ))}
          </ul>
        )}
      </Band>
    </div>
  );
}
