import { shiftFromHour, shifts, shiftOrder } from "@/lib/campaign";
import { useShift } from "@/components/providers";
import { cn } from "@/lib/utils";

export function ShiftSwitch({ compact = false }: { compact?: boolean }) {
  const { shift, mode, setShift, followLive } = useShift();
  const liveShift = shiftFromHour(new Date().getHours());
  const displayedShift = mode === "live" ? liveShift : shift;

  return (
    <div className={cn("flex items-center gap-1", compact ? "" : "flex-wrap")}>
      {shiftOrder.map((id) => {
        const active = displayedShift === id;
        return (
          <button
            key={id}
            type="button"
            onClick={() => setShift(id)}
            aria-pressed={active}
            className={cn(
              "kicker h-9 rounded-full px-3 transition-colors duration-150",
              active ? "bg-blood text-paper" : "text-current/70 hover:text-current",
            )}
          >
            {compact ? shifts[id].name.replace("shift", "") : shifts[id].name}
          </button>
        );
      })}
      {mode === "lock" ? (
        <button
          type="button"
          onClick={followLive}
          className="kicker relative z-50 h-9 cursor-pointer px-2 text-current/55 hover:text-current"
          aria-label="Return to live city cycle"
        >
          Live
        </button>
      ) : null}
    </div>
  );
}
